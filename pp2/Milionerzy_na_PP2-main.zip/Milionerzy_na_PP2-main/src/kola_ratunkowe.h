#ifndef KOLA_RATUNKOWE_H
#define KOLA_RATUNKOWE_H

typedef char string[256];
void fiftyFifty(char correctAnswer, string answers[4]);
void call_to_friend();
void clear_input_buffer();
void PytanieDoPublicznosci(char correctAnswer, string answers[4], string question);
#endif
