#include "kola_ratunkowe.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h> //losowe liczby
#include <stdbool.h> //bool
#include <string.h>
#include <ctype.h>