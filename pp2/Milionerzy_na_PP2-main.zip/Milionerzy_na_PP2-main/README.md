Moje [prawa autorskie](https://github.com/user-attachments/assets/858cb878-e621-498b-9fcb-fd9d2d94fe11) 





